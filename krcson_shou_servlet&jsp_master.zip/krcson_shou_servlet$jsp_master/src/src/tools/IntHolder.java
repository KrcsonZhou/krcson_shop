package src.tools;

public class IntHolder {
	public int value;

	public IntHolder(int i) {
		this.value = i;
	}
}
